module ru.vasilevv.vasilevd_doptask2 {
    requires javafx.controls;
    requires javafx.fxml;


    opens ru.vasilevv.vasilevd_doptask2 to javafx.fxml;
    exports ru.vasilevv.vasilevd_doptask2;
}