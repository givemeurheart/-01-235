module ru.vasilevv.vasilevd_doptask1 {
    requires javafx.controls;
    requires javafx.fxml;


    opens ru.vasilevv.vasilevd_doptask1 to javafx.fxml;
    exports ru.vasilevv.vasilevd_doptask1;
}